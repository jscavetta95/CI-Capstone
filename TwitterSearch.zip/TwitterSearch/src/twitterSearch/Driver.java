/*Copyright 2007 Yusuke Yamamoto

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
Distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.*/

package twitterSearch;

import java.sql.*;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

public class Driver {

	public static void main(String[] args) throws TwitterException, SQLException {
		ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
		String USER = "root";
		String PASS = "mysql";
		String DB_URL = "jdbc:mysql://localhost:3306/twitterDatabase";
		Connection conn = null;
		configurationBuilder.setDebugEnabled(true)
							.setOAuthConsumerKey("1qvJzIC4ZDTemWvDkQ77w7ZwX")
							.setOAuthConsumerSecret("2qYFoW68Okn6tA2VBJrkd0ksaBPOuy17TG1xkZj06D7cADgRud")
							.setOAuthAccessToken("793788156621492224-sA1OiYOwx02EEdrE0MzGwTAf5OKxtLZ")
							.setOAuthAccessTokenSecret("BZ3p5VpW8Q3I8KQZLG1xLjZMaFacFSCXX24HyuaIvZ5Dw");
		
		TwitterFactory twitterFactory = new TwitterFactory(configurationBuilder.build());
		Twitter twitter = twitterFactory.getInstance();
		
		Query query = new Query("bitcoin");
	    QueryResult result = twitter.search(query);
	    
	    System.out.print("\nConnecting to database...");
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
        System.out.println(" SUCCESS!\n");

	    
	    for (Status status : result.getTweets()) {
	        System.out.println("@" + status.getUser().getCreatedAt() + ":" + status.getText());
	        
	        System.out.print("\nInserting records into table...");
	        
	        String sql = "INSERT INTO TwitterData (date, tweet)" + 
	        		"VALUES (?, ?)";
	        
	        PreparedStatement preparedStatement = conn.prepareStatement(sql);
	        preparedStatement.setDate(1, new java.sql.Date(status.getUser().getCreatedAt().getTime()));
	        preparedStatement.setString(2, status.getText());
	        preparedStatement.executeUpdate(); 

	            System.out.println(" SUCCESS!\n");
	    }
	}
}
